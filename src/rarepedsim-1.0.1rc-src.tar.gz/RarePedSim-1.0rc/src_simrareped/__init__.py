#!/usr/bin/python
# Copyright (c) 2013-2014 Biao Li <biaol@bcm.edu>
# GNU General Public License (http://www.gnu.org/licenses/gpl.html)
VERSION = '1.0rc'
HOMEPAGE = 'http://bioinformatics.org/simped/rare'